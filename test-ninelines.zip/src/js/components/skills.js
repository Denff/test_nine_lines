// if (document.querySelector('.anketa__skills')) {

//     const checkboxesInner = document.querySelector('.anketa__checkboxes-inner');
//     let checkboxes = [];
//     for( let i = 0; i < checkboxes.length; i++) {
//         checkboxes.length = 12;
//         let label = document.createElement('label');
//         label.classList.add('anketa__skill-label');
//         let input = document.createElement('input');
//         input.setAttribute('type', 'checkbox');
//         input.classList.add('checkbox');
//         label.appendChild(input)
//         checkboxesInner.appendChild(label);

//         checkboxes[i] = label[i];
//     }
// }

